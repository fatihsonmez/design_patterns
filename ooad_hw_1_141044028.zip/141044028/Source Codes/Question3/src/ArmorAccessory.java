public abstract class ArmorAccessory implements Armor{

    protected Armor armor;

    public ArmorAccessory(Armor newArmor){
        this.armor = newArmor;
    }

    public int getCost() {
        return this.armor.getCost();
    }

    public double getWeight(){
        return this.armor.getWeight();
    }
}
