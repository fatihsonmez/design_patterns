public class AutoRifle extends ArmorAccessory {
    public AutoRifle(Armor newArmor) {
        super(newArmor);
        System.out.println("Adding the auto rifle...");
        System.out.println("Now you can shoot people with auto rifle.\n");
    }

    public int getCost() {
        return armor.getCost() + 30000;
    }

    public double getWeight() {
        return armor.getWeight() + 1.5;
    }
}
