public interface Armor {
    public double getWeight();
    public int getCost();
}
