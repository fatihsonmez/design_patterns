public class RocketLauncher extends ArmorAccessory {
    public RocketLauncher(Armor newArmor) {
        super(newArmor);
        System.out.println("Adding the rocket launcher...");
        System.out.println("Now you can launch rockets.\n");
    }

    @Override
    public double getWeight() {
        return armor.getWeight() + 7.5;
    }

    @Override
    public int getCost() {
        return armor.getCost() + 150000;
    }

}
