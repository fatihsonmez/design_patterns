public class Tor implements Armor {
    @Override
    public double getWeight() {
        return 50;
    }

    @Override
    public int getCost() {
        return 5000000;
    }
}
