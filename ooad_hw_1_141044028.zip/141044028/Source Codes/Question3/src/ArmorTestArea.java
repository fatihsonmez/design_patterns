import java.util.Scanner;

public class ArmorTestArea {
    public static void main(String[] args) {

        System.out.println("Welcome to the test area of Zırhsan A.Ş.");
        System.out.println("Okay, now choose the base of the armor.");
        System.out.print("Dec: 1\nOra: 2\nTor: 3");

        Scanner scanner = new Scanner(System.in);
        int baseChoice = scanner.nextInt();

        Armor armor;

        if(baseChoice == 1) {
            armor = new Dec();
            System.out.println("Dec, a good choice...");
        }
        else if(baseChoice == 2) {
            armor = new Ora();
            System.out.println("Ora, a good choice...");
        }
        else if(baseChoice == 3) {
            armor = new Tor();
            System.out.println("Tor, a good choice...");
        }
        else{
            armor = new Tor();
            System.out.println("Your choice was something else so we give you Tor.\n");
        }

        System.out.println("\nNow adding the extras to armor");

        int accessoryChoice = 0;
        do{
            System.out.println("Flamethrower: 1\nAutorifle: 2\nLaser: 3\nRocketLauncher: 4\nIf enough: 5");
            accessoryChoice = scanner.nextInt();
            if(accessoryChoice == 1)
                armor = new Flamethrower(armor);
            else if(accessoryChoice == 2)
                armor = new AutoRifle(armor);
            else if(accessoryChoice == 3)
                armor = new Laser(armor);
            else if(accessoryChoice == 4)
                armor = new RocketLauncher(armor);
        }while(accessoryChoice != 5);

        System.out.println("The cost of this armor is: " + armor.getCost());
        System.out.println("The weight of this armor is: " + armor.getWeight());
    }
}
