public class Flamethrower extends ArmorAccessory {

    public Flamethrower(Armor newArmor) {
        super(newArmor);
        System.out.println("Adding the flamethrower...");
        System.out.println("Now you can throw flames.\n");
    }

    public int getCost() {
        return armor.getCost() + 50000;
    }

    public double getWeight(){
        return armor.getWeight() + 2;
    }
}
