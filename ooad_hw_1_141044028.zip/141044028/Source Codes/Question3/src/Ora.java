public class Ora implements Armor {
    @Override
    public double getWeight() {
        return 30;
    }

    @Override
    public int getCost() {
        return 1500000;
    }
}
