public class Dec implements Armor {
    @Override
    public double getWeight() {
        return 25;
    }

    @Override
    public int getCost() {
        return 500000;
    }
}
