public class Laser extends ArmorAccessory {
    public Laser(Armor newArmor) {
        super(newArmor);
        System.out.println("Adding the laser...");
        System.out.println("Now you can beam lasers.\n");
    }

    @Override
    public int getCost() {
        return armor.getCost() + 200000;
    }

    @Override
    public double getWeight() {
        return armor.getWeight() + 5.5;
    }
}
