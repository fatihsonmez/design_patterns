public interface LinearSolver {
    public void solve();
}
