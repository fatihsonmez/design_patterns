public class LinearSolverDeluxe {
    LinearSolver solver;

    public void setSolver(LinearSolver newSolver){
        this.solver = newSolver;
    }

    public void solve(){
        solver.solve();
    }
}
