public class MatrixInversion implements LinearSolver {

    public void solve() {
        System.out.println("I solve the system via MatrixInversion...");
    }
}
