public class Classroom {

    public static void main(String[] args) {
        System.out.println("hello, this is a classroom.");
        LinearSolverDeluxe lsd = new LinearSolverDeluxe();
        lsd.setSolver(new GaussianElimination());
        lsd.solve();
        lsd.setSolver(new MatrixInversion());
        lsd.solve();

    }
}
