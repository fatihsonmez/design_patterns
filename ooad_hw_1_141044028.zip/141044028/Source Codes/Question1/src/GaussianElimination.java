public class GaussianElimination implements LinearSolver {

    public void solve() {
        System.out.println("I solve the system via Gaussian...");
    }
}
