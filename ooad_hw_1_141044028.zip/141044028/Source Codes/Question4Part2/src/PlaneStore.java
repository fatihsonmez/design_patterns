public abstract class PlaneStore {

    PlaneEquipmentFactory planeEquipmentFactory;

    public Plane orderPlane(int modelNumber){

        Plane plane = createPlane(modelNumber);

        plane.prepare();
        plane.constructSkeleton();
        plane.placeEngines();
        plane.placeSeats();

        return plane;
    }


    protected Plane createPlane(int modelNumber){
        Plane plane = null;

        if(modelNumber == 1){
            plane = new PlaneTPX100(planeEquipmentFactory);
        }
        else if(modelNumber == 2){
            plane = new PlaneTPX200(planeEquipmentFactory);
        }
        else if(modelNumber == 3){
            plane = new PlaneTPX300(planeEquipmentFactory);
        }

        return plane;
    }
}
