public class EurasiaPlaneStore extends PlaneStore {
    EurasiaPlaneStore(){
        this.planeEquipmentFactory = new EurasiaPlaneEquipmentFactory();
    }
}
