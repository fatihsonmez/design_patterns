public class VelvetSeat extends Seat {
    VelvetSeat(){
        this.typeOfSeats = "Velvet";
    }
}
