public class DomesticPlaneEquipmentFactory implements PlaneEquipmentFactory {
    @Override
    public Engine createEngine() {
        return new TurbojetEngine();
    }

    @Override
    public Seat createSeat() {
        return new VelvetSeat();
    }
}
