public abstract class Seat {

    protected String typeOfSeats;
    protected String numberOfSeats;

    public void setNumberOfSeats(String numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public String toString(){
        return "upholster type is " + this.typeOfSeats + " and number of seats is " + numberOfSeats;
    }
}
