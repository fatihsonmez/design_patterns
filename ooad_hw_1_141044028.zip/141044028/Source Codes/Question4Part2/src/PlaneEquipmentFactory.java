public interface PlaneEquipmentFactory {
    public Engine createEngine();
    public Seat createSeat();
}
