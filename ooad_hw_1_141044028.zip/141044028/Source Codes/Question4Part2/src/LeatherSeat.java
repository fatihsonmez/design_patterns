public class LeatherSeat extends Seat {
    LeatherSeat(){
        this.typeOfSeats = "Leather";
    }
}
