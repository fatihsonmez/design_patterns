public class TurbojetEngine extends Engine {
    TurbojetEngine(){
        this.typeOfEngines = "Turbojet";
    }

}
