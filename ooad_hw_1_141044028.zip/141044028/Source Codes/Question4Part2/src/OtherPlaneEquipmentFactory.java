public class OtherPlaneEquipmentFactory implements PlaneEquipmentFactory {
    @Override
    public Engine createEngine() {
        return new GearedTurbofanEngine();
    }

    @Override
    public Seat createSeat() {
        return new LeatherSeat();
    }
}
