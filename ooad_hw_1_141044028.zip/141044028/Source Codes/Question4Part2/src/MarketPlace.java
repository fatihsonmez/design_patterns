public class MarketPlace {
    public static void main(String[] args) {
        System.out.println("hello world");

        PlaneStore psd = new DomesticPlaneStore();
        Plane d1 = psd.orderPlane(1);
        Plane d2 = psd.orderPlane(2);
        Plane d3 = psd.orderPlane(3);

        PlaneStore pse = new EurasiaPlaneStore();
        Plane e1 = pse.orderPlane(1);
        Plane e2 = pse.orderPlane(2);
        Plane e3 = pse.orderPlane(3);

        PlaneStore pso = new OtherPlaneStore();
        Plane o1 = pso.orderPlane(1);
        Plane o2 = pso.orderPlane(2);
        Plane o3 = pso.orderPlane(3);


        System.out.println("We have 3 different type of planes, in 3 different areas...");
        System.out.println();

        System.out.println("Domestic types:\n");
        System.out.println(d1);
        System.out.println();
        System.out.println(d2);
        System.out.println();
        System.out.println(d3);
        System.out.println("\n");

        System.out.println("Eurasia types:\n");
        System.out.println(e1);
        System.out.println();
        System.out.println(e2);
        System.out.println();
        System.out.println(e3);
        System.out.println("\n");

        System.out.println("Other types:\n");
        System.out.println(o1);
        System.out.println();
        System.out.println(o2);
        System.out.println();
        System.out.println(o3);
    }
}
