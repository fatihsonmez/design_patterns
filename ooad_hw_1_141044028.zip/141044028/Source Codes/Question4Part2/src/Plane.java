public abstract class Plane {

    protected String model;
    protected String purpose;
    protected String skeleton;
    protected Engine engine;
    protected Seat seat;

    protected PlaneEquipmentFactory planeEquipmentFactory;

    public void prepare(){
        engine = planeEquipmentFactory.createEngine();
        seat = planeEquipmentFactory.createSeat();
    }
    public abstract void constructSkeleton();
    public abstract void placeEngines();
    public abstract void placeSeats();

    @Override
    public String toString() {
        return "Model name: " + model + "\nPurpose: " + purpose + "\nSkeleton: " + skeleton +
                "\nEngine: " + engine + "\nSeating: " + seat;
    }
}
