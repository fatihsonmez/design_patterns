public class EurasiaPlaneEquipmentFactory implements PlaneEquipmentFactory {
    @Override
    public Engine createEngine() {
        return new TurbofanEngine();
    }

    @Override
    public Seat createSeat() {
        return new LinenSeat();
    }
}
