public class OtherPlaneStore extends PlaneStore {
    OtherPlaneStore(){
        this.planeEquipmentFactory = new OtherPlaneEquipmentFactory();
    }
}
