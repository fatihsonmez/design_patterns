public class TurbofanEngine extends Engine {
    TurbofanEngine(){
        this.typeOfEngines = "Turbofan";
    }

}
