public class PlaneTPX200 extends Plane {

    PlaneTPX200(PlaneEquipmentFactory planeEquipmentFactory){
        this.planeEquipmentFactory = planeEquipmentFactory;
        this.model = "TPX200";
        this.purpose = "Domestic and short international flights";
    }

    @Override
    public void constructSkeleton() {
        this.skeleton = "Nickel alloy";
    }

    @Override
    public void placeEngines() {
        this.engine.setNumberOfEngines("Twin jet engines");
    }

    @Override
    public void placeSeats() {
        this.seat.setNumberOfSeats("100 seats");
    }
}
