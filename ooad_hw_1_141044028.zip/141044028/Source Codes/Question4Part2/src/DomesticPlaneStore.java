public class DomesticPlaneStore extends PlaneStore {
    DomesticPlaneStore(){
        this.planeEquipmentFactory = new DomesticPlaneEquipmentFactory();
    }
}
