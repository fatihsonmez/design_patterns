public class GearedTurbofanEngine extends Engine  {
    GearedTurbofanEngine(){
        this.typeOfEngines = "Geared turbofan";
    }
}
