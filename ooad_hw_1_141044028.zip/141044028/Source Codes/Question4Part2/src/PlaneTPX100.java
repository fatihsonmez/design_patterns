public class PlaneTPX100 extends Plane {

    public PlaneTPX100(PlaneEquipmentFactory planeEquipmentFactory){
        this.planeEquipmentFactory = planeEquipmentFactory;
        this.model = "TPX100";
        this.purpose = "Domestic flights";
    }



    @Override
    public void constructSkeleton() {
        this.skeleton = "Aluminum alloy";
    }

    @Override
    public void placeEngines() {
        this.engine.setNumberOfEngines("Single jet engine");
    }

    @Override
    public void placeSeats() {
        this.seat.setNumberOfSeats("50 seats");
    }
}
