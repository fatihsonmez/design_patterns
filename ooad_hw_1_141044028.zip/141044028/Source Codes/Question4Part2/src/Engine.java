public abstract class Engine {

    protected String typeOfEngines;
    protected String numberOfEngines;

    public void setNumberOfEngines(String numberOfEngines) {
        this.numberOfEngines = numberOfEngines;
    }

    public String toString(){
        return "injection type is "  + this.typeOfEngines + " and number type is " + numberOfEngines + " ";
    }
}
