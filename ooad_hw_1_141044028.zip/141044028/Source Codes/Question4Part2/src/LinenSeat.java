public class LinenSeat extends Seat {
    LinenSeat(){
        this.typeOfSeats = "Linen";
    }
}
