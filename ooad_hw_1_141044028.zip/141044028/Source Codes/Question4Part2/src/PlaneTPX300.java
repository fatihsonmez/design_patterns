public class PlaneTPX300 extends Plane {

    PlaneTPX300(PlaneEquipmentFactory planeEquipmentFactory){
        this.planeEquipmentFactory = planeEquipmentFactory;
        this.model = "TPX300";
        this.purpose = "Transatlantic flights";
    }

    @Override
    public void constructSkeleton() {
        this.skeleton = "Titanium alloy";
    }

    @Override
    public void placeEngines() {
        this.engine.setNumberOfEngines("Quadro jet engines");
    }

    @Override
    public void placeSeats() {
        this.seat.setNumberOfSeats("250 seats");
    }
}
