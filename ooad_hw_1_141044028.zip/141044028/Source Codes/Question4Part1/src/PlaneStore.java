public class PlaneStore {

    SimplePlaneFactory factory;

    public PlaneStore(SimplePlaneFactory factory){
        this.factory = factory;
    }

    public Plane orderPlane(int modelNumber){
        Plane plane;

        plane = factory.createPlane(modelNumber);

        plane.constructSkeleton();
        plane.placeEngines();
        plane.placeSeats();

        return plane;
    }
}
