import java.util.Scanner;

public class MarketPlace {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PlaneStore planeStore = new PlaneStore(new SimplePlaneFactory());
        Plane plane;
        int modelNumber;

        System.out.println("Welcome to the marketplace, we make the best planes...");
        System.out.println("Please select the plane you want: ");
        System.out.println("for TPX100 1\nfor TPX200 2\nfor TPX300 3:");

        modelNumber = scanner.nextInt();
        plane = planeStore.orderPlane(modelNumber);

        System.out.println("The plane you bought:");
        System.out.println(plane);
    }
}
