public class PlaneTPX300 extends Plane {

    PlaneTPX300(String model, String purpose) {
        super(model, purpose);
    }

    @Override
    public void constructSkeleton() {
        this.skeleton = "Titanium alloy";
    }

    @Override
    public void placeEngines() {
        this.engine = "Quadro jet engines";
    }

    @Override
    public void placeSeats() {
        this.seating = "250 seats";
    }
}
