public class SimplePlaneFactory {


    public Plane createPlane(int modelNumber){
        Plane plane = null;

        if(modelNumber == 1)
            plane = new PlaneTPX100("TPX100", "Domestic flights");
        if(modelNumber == 2)
            plane = new PlaneTPX200("TPX200", "Domestic and short international flights");
        if(modelNumber == 3)
            plane = new PlaneTPX300("TPX300", "Transatlantic flights");

        return plane;
    }
}
