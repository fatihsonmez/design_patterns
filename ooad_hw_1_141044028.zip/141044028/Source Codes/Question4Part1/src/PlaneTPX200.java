public class PlaneTPX200 extends Plane {

    PlaneTPX200(String model, String purpose) {
        super(model, purpose);
    }

    @Override
    public void constructSkeleton() {
        this.skeleton = "Nickel alloy";
    }

    @Override
    public void placeEngines() {
        this.engine = "Twin jet engines";
    }

    @Override
    public void placeSeats() {
        this.seating = "100 seats";
    }
}
