public abstract class Plane {
    private String model;
    private String purpose;
    protected String skeleton;
    protected String engine;
    protected String seating;

    Plane(String model, String purpose){
        this.model = model;
        this.purpose = purpose;
    }
    public abstract void constructSkeleton();
    public abstract void placeEngines();
    public abstract void placeSeats();

    @Override
    public String toString() {
        return "Model name: " + model + "\nPurpose: " + purpose + "\nSkeleton: " + skeleton +
                "\nEngine: " + engine + "\nSeat: " + seating;
    }
}
