public class PlaneTPX100 extends Plane {


    PlaneTPX100(String model, String purpose) {
        super(model, purpose);
    }

    @Override
    public void constructSkeleton() {
        this.skeleton = "Aluminum alloy";
    }

    @Override
    public void placeEngines() {
        this.engine = "Single jet engine";
    }

    @Override
    public void placeSeats() {
        this.seating = "50 seats";
    }
}
