import java.nio.charset.IllegalCharsetNameException;
import java.util.ArrayList;

public class Human implements Observer{

    private String name;
    ArrayList<Integer> subscriptionType;

    Human(String name){
        this.name = name;
        subscriptionType = new ArrayList<>();
    }

    @Override
    public void update(Content content) {
        System.out.println("I am " + name + " and I got a content which says: " + content);
    }

    public ArrayList<Integer> getSubscriptionTyepe() {
        return subscriptionType;
    }

    public void addToSubscriptionType(Integer subscriptionType){
        this.subscriptionType.add(subscriptionType);
    }
}
