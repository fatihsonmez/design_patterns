public class Image implements Content {
    private String value;
    Image(){
        this.value = "I am an image content.";
    }

    @Override
    public String toString() {
        return ""+ value;
    }
}
