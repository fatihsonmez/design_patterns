import java.util.ArrayList;

public interface Subject {
    public void registerObserver(Observer observer, int registryType);
    public void removeObserver(Observer observer, int cancellationType);
    public void notifyObservers(ArrayList<Observer> observers, Content content);

    public void publishText();
    public void publishImage();
    public void publishAudio();
}
