public class ObservableUniverse {
    public static void main(String[] args) {
        Website website = new Website();
        website.registerObserver(new Human("Ahmet"), 1);
        website.registerObserver(new Human("Mehmet"), 2);
        website.registerObserver(new Human("Fatih"), 3);
        website.publishText();
        website.publishImage();
        website.publishAudio();
    }
}
