import java.util.ArrayList;

public interface Observer {
    public void update(Content x);
    public ArrayList<Integer> getSubscriptionTyepe();
    public void addToSubscriptionType(Integer subscriptionType);
}
