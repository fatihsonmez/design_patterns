public interface Content {

}
