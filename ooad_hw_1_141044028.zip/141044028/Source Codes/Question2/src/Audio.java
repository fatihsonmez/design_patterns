public class Audio implements Content {
    private String value;
    Audio(){
        this.value ="I am an audio content.";
    }

    @Override
    public String toString() {
        return "" + value;
    }
}
