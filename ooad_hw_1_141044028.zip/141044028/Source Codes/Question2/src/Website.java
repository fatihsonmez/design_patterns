import java.util.ArrayList;

public class Website implements Subject {
    private ArrayList<Observer> textObservers;
    private ArrayList<Observer> imageObservers;
    private ArrayList<Observer> audioObservers;

    Website(){
        textObservers = new ArrayList<>();
        imageObservers = new ArrayList<>();
        audioObservers = new ArrayList<>();
    }

    @Override
    public void registerObserver(Observer observer, int registryType) {
        if(registryType == 1){
            textObservers.add(observer);
            observer.getSubscriptionTyepe().add(1);
        }
        else if(registryType == 2){
            imageObservers.add(observer);
            observer.getSubscriptionTyepe().add(2);
        }
        else if(registryType == 3){
            audioObservers.add(observer);
            observer.getSubscriptionTyepe().add(3);
        }
    }

    @Override
    public void removeObserver(Observer observer, int cancellationType) {
        if(cancellationType == 1){
            int observerIndex = textObservers.indexOf(observer);
            textObservers.remove(observerIndex);

            int contentIndex = observer.getSubscriptionTyepe().indexOf(cancellationType);
            observer.getSubscriptionTyepe().remove(contentIndex);
        }
        else if(cancellationType == 2){
            int observerIndex = imageObservers.indexOf(observer);
            imageObservers.remove(observerIndex);

            int contentIndex = observer.getSubscriptionTyepe().indexOf(cancellationType);
            observer.getSubscriptionTyepe().remove(contentIndex);
        }
        else if(cancellationType == 3){
            int observerIndex = audioObservers.indexOf(observer);
            audioObservers.remove(observerIndex);

            int contentIndex = observer.getSubscriptionTyepe().indexOf(cancellationType);
            observer.getSubscriptionTyepe().remove(contentIndex);
        }
    }

    @Override
    public void notifyObservers(ArrayList<Observer> arrayList, Content content) {
        for(int i = 0; i < arrayList.size(); i++){
            arrayList.get(i).update(content);
        }
    }

    @Override
    public void publishText() {
        Content text = new Text();
        notifyObservers(textObservers, text);
    }

    @Override
    public void publishImage() {
        Content image = new Image();
        notifyObservers(imageObservers, image);
    }

    @Override
    public void publishAudio() {
        Content audio = new Audio();
        notifyObservers(audioObservers, audio);
    }


}
