public class Text implements Content {

    private String value;
    Text(){
        this.value = "I am a text content.";
    }

    @Override
    public String toString() {
        return "" + value;
    }
}
